<?php
$server = "localhost";
$username = "uhdflbft_bdveterinaria";
$password = "Ejr82tgDNy66Y6Ga7ah7";
$database = "uhdflbft_bdveterinaria";

$mysqli = new mysqli($server, $username, $password, $database);

// Verifica la conexión
if ($mysqli->connect_error) {
    die("Conexión fallida: " . $mysqli->connect_error);
}

// Establece el conjunto de caracteres
$mysqli->set_charset("utf8mb4");
?>
