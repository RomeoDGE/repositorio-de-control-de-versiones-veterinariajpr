<?php
// Conexión a la base de datos
$servername = "localhost";
$username = "uhdflbft_bdveterinaria";
$password = "Ejr82tgDNy66Y6Ga7ah7";  // Cambia esto si tienes una contraseña configurada
$dbname = "uhdflbft_bdveterinaria";  // Nombre de tu base de datos

$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Error en la conexión: " . $conn->connect_error);
}

// Obtener los datos del formulario
$usuario = $_POST['usuario'];
$contrasena = password_hash($_POST['contrasena'], PASSWORD_DEFAULT); // Encriptar la contraseña
$correo = $_POST['correo'];
$nombre = $_POST['nombre'];
$apaterno = $_POST['apaterno'];
$amaterno = $_POST['amaterno'];

// Verificar si el usuario o correo ya existen
$sql = "SELECT * FROM veterinario WHERE usuario = ? OR correo = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $usuario, $correo);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Usuario o correo ya existen
    echo json_encode(["status" => "error", "message" => "El nombre de usuario o correo ya existen."]);
} else {
    // Insertar el nuevo veterinario
    $sql_insert = "INSERT INTO veterinario (usuario, contrasena, correo, nombre, apaterno, amaterno) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt_insert = $conn->prepare($sql_insert);
    $stmt_insert->bind_param("ssssss", $usuario, $contrasena, $correo, $nombre, $apaterno, $amaterno);

    if ($stmt_insert->execute()) {
        // Registro exitoso
        echo json_encode(["status" => "success", "message" => "Registro exitoso."]);
    } else {
        // Error al insertar, muestra el mensaje de error específico
        echo json_encode(["status" => "error", "message" => "Hubo un error al registrar: " . $conn->error]);
    }

    $stmt_insert->close();
}

$stmt->close();
$conn->close();
?>
