<?php
session_start();

// Verificar si el usuario está autenticado
if (!isset($_SESSION['autenticado']) || $_SESSION['autenticado'] !== true) {
    // Si no está autenticado, redirigir al login
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agendar Cita</title>
    <link rel="stylesheet" href="../styles/stylesC.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <style>
        .back-button {
            position: absolute;
            top: 20px; /* Ajusta la posición superior según tu diseño */
            left: 20px; /* Ajusta la posición izquierda según tu diseño */
            cursor: pointer;
            padding: 10px; /* Agrega un relleno al botón para darle más espacio */
        }
    </style>
</head>
<body>
<a href="javascript:history.back()" class="back-button">
        <svg width="45" height="45" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
            <path d="M512 256A256 256 0 1 0 0 256a256 256 0 1 0 512 0zM217.4 376.9L117.5 269.8c-3.5-3.8-5.5-8.7-5.5-13.8s2-10.1 5.5-13.8l99.9-107.1c4.2-4.5 10.1-7.1 16.3-7.1c12.3 0 22.3 10 22.3 22.3l0 57.7 96 0c17.7 0 32 14.3 32 32l0 32c0 17.7-14.3 32-32 32l-96 0 0 57.7c0 12.3-10 22.3-22.3 22.3c-6.2 0-12.1-2.6-16.3-7.1z"/>
        </svg>
    </a>
    <div class="container">
        <div class="header">
            <span class="icon syringe-left">💉</span>
            <h2>AGENDAR CITA</h2>
            <span class="icon syringe-right">💉</span>
        </div>

        <div class="content">
            <form id="agendar-cita-form" method="post" action="procesar_cita.php">
                <label for="codigo-mascota">Código Mascota</label>
                <div class="search-bar">
                    <input type="text" id="codigo-mascota" name="codigo_mascota" required>
                    <button type="button" onclick="openSearchModal()"><img src="search-icon.png" alt="Search"></button>
                </div>

                <label for="fecha-cita">FECHA DE CITA</label>
                <div class="input-group">
                    <input type="text" id="fecha-cita" name="fecha_cita" placeholder="DD/MM/AA" required>
                    <button type="button" onclick="openDatePicker()"><img src="calendar-icon.png" alt="Calendar"></button>
                </div>

                <label for="hora-cita">HORA DE CITA</label>
                <div class="input-group">
                    <input type="text" id="hora-cita" name="hora_cita" placeholder="00:00" required>
                    <button type="button" onclick="openTimePicker()"><img src="clock-icon.png" alt="Clock"></button>
                </div>

                <div class="buttons">
                    <button type="submit" class="btn save" onclick="showSaveAlert(event)">💾</button>
                </div>
            </form>
        </div>
    </div>

    <script src="../scripts/scripts.js"></script>
    <script>
        // Inicializar Flatpickr para la fecha
        flatpickr("#fecha-cita", {
            dateFormat: "Y-m-d",
            altInput: true,
            altFormat: "d/m/Y",
            allowInput: true
        });

        // Inicializar Flatpickr para la hora
        flatpickr("#hora-cita", {
            enableTime: true,
            noCalendar: true,
            dateFormat: "H:i",
            altInput: true,
            altFormat: "H:i",
            allowInput: true
        });

        function showCancelAlert() {
            Swal.fire({
                title: '¿Estás seguro?',
                text: "¡Los cambios no se guardarán!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Sí, cancelar',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    // Limpiar formulario
                    document.getElementById('agendar-cita-form').reset();
                }
            });
        }

        function showSaveAlert(event) {
    event.preventDefault(); // Previene el envío automático del formulario

    Swal.fire({
        title: '¿Estás seguro?',
        text: "¡Deseas guardar esta cita!",
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Sí, guardar',
        cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.isConfirmed) {
            fetch('procesar_cita.php', {
                method: 'POST',
                body: new FormData(document.getElementById('agendar-cita-form'))
            }).then(response => response.json())
              .then(data => {
                  if (data.status === 'success') {
                      Swal.fire({
                          icon: 'success',
                          title: 'Cita Agendada',
                          text: data.message,
                          showConfirmButton: true
                      }).then(() => {
                          window.location.href = "../vistas/ver_citas.php";
                      });
                  } else {
                      Swal.fire({
                          icon: 'error',
                          title: 'Error',
                          text: data.message,
                          showConfirmButton: true
                      });
                  }
              }).catch(error => {
                  console.error('Error:', error);
              });
        }
    });
}

    </script>
</body>
</html>
