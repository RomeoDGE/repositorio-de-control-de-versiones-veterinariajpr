<?php
session_start();

// Verificar si el usuario está autenticado
if (!isset($_SESSION['autenticado']) || $_SESSION['autenticado'] !== true) {
    // Si no está autenticado, redirigir al login
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"&amp;gt;>
    <title>Veterinaria - JRP</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles/stylesHome.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <script>
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('service-worker.js')
      .then((registration) => {
        console.log('Service Worker registrado con éxito:', registration);
      })
      .catch((error) => {
        console.log('Error al registrar el Service Worker:', error);
      });
  }
</script>
<style>
    body {
            background-color: #0cd4da;          
        }
</style>
</head>
<body>
    <header class="bg-morado text-white py-3">
        <div class="container">
        <nav class="navbar navbar-expand-lg navbar-dark">
                <a class="navbar-brand" href="#">
                    <img src="imgvet/logovet1.jpg" height="50px" width="50px" alt="Vet Solutions Logo" class="logo">
                    VetSoft
                </a>
                <!-- Botón de hamburguesa para pantallas pequeñas -->
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="calendario_vacunacion/Calvac.php">
                                <div class="nav-rectangle">
                                    <img src="imgvet/calendar.svg" alt="Icono Servicio 1">
                                    <span class="nav-text">Calendario</span>
                                </div>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="consulta/consulta.php">
                                <div class="nav-rectangle">
                                    <img src="imgvet/consulta.svg" alt="Icono Servicio 1">
                                    <span class="nav-text">Consulta</span>
                                </div>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="procesos/RegistroMC.php">
                                <div class="nav-rectangle">
                                    <img src="imgvet/iconcat.svg" alt="Icono Servicio 2">
                                    <span class="nav-text">Registrar</span>
                                </div>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="cerrarsesion.php" onclick="return cerrarSesion();">
                                <div class="nav-rectangle">
                                    <img src="imgvet/icondoctor.svg" alt="Icono Servicio 3">
                                    <span class="nav-text">
                                        <?php
                                        if (isset($_SESSION['autenticado']) && $_SESSION['autenticado'] === true && isset($_SESSION['usuario'])) {
                                            echo $_SESSION['usuario'];
                                        }
                                        ?>
                                    </span>
                                </div>
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>
            
            <div class="row">
                <div class="col-lg-6">
                    <h1 class="display-4 glowing-text">Bienvenidos a VetSoft</h1>
                    <p class="lead">Sistema para la veterinaria JRP</p>
                    <a href="procesos/citas.php" class="btn btn-light btn-lg btn-custom">Agendar cita</a>
                    <a href="vistas/ver_citas.php" class="btn btn-light btn-lg btn-custom">Ver citas</a>
                </div>
                <div class="col-lg-6 text-center">
                    <div class="header-image-container">
                        <img src="imgvet/vet-enfermera.jpg" height="250px" width="250px" alt="Veterinaria" class="img-fluid rounded-circle mt-4">
                    </div>
                </div>
            </div>
        </div>
    </header>
    <div id="carouselBanner" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#carouselBanner" data-slide-to="0" class="active"></li>
            <li data-target="#carouselBanner" data-slide-to="1"></li>
            <li data-target="#carouselBanner" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="imgvet/vetgato.png" class="d-block w-100" alt="Mascota 1">
            </div>
            <div class="carousel-item">
                <img src="imgvet/vetperrogato.jpg" class="d-block w-100 " alt="Mascota 2">
            </div>
            <div class="carousel-item">
                <img src="imgvet/vetperro1.png" class="d-block w-100" alt="Mascota 3">
            </div>
        </div>
        <a class="carousel-control-prev" href="#carouselBanner" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Anterior</span>
        </a>
        <a class="carousel-control-next" href="#carouselBanner" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Siguiente</span>
        </a>
    </div>
    <section id="submodulos">
    <a href="vistas/ver_consulta.php" class="btn btn-light btn-lg btn-custom">Ver Consultas</a>
    <a href="vistas/ver_HMedico.php" class="btn btn-light btn-lg btn-custom">Ver Historial Médico</a>
    <a href="calendario_vacunacion/Calvac.php" class="btn btn-light btn-lg btn-custom">Ver Calendario</a>
    <a href="vistas/clientes.php" class="btn btn-light btn-lg btn-custom">Ver Clientes</a>
    </section>
    <footer>
        <p>&copy; 2024 Veterinaria JRP</p>
    </footer>
    
    <script>
    function cerrarSesion() {
        // Muestra una alerta personalizada con SweetAlert2
        Swal.fire({
            title: '¿Seguro que deseas cerrar sesión?',
            text: 'Tu sesión actual se cerrará y tendrás que volver a iniciar sesión.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Sí, cerrar sesión',
            cancelButtonText: 'Cancelar',
        }).then((result) => {
            if (result.isConfirmed) {
                // Si el usuario confirma, redirige a la página de cierre de sesión
                window.location.href = "procesos/cerrarsesion.php";
            }
        });
        return false; // Importante: Evita que el enlace se ejecute automáticamente
    }
    </script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="efectos.js"></script>
</body>
</html>
