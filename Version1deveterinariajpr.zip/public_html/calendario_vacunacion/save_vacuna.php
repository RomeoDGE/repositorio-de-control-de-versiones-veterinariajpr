<?php
// Configuración de la base de datos
$servername = "localhost";  
$username = "uhdflbft_bdveterinaria";         
$password = "Ejr82tgDNy66Y6Ga7ah7";             
$dbname = "uhdflbft_bdveterinaria"; 

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Conexión fallida: ' . $conn->connect_error]);
    exit;
}

// Obtener datos del formulario
$codigo_mascota = $_POST['codigo_mascota'];
$fecha_vacuna = $_POST['fecha_vacunacion'];
$enfermedad = $_POST['enfermedad'];

// Validar que los datos no estén vacíos
if (empty($codigo_mascota) || empty($fecha_vacuna) || empty($enfermedad)) {
    echo json_encode(['success' => false, 'message' => 'Todos los campos son obligatorios.']);
    exit;
}

// Preparar y ejecutar la consulta SQL
$sql = "INSERT INTO calendario_vacunacion (codigo_mascota, fecha_vacuna, enfermedad) VALUES (?, ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param("sss", $codigo_mascota, $fecha_vacuna, $enfermedad);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Datos guardados correctamente']);
} else {
    echo json_encode(['success' => false, 'message' => 'Error: ' . $conn->error]);
}

// Cerrar conexión
$stmt->close();
$conn->close();
?>
