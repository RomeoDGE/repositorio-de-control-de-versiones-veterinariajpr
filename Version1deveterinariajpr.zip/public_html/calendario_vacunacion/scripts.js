function showSaveAlert() {
    // Obtener los datos del formulario
    const codigoMascota = document.getElementById('codigo-mascota').value;
    const fechaVacunacion = document.getElementById('fecha-vacunacion').value;
    const enfermedad = document.getElementById('enfermedad').value;

    // Validación básica
    if (!codigoMascota || !fechaVacunacion || !enfermedad) {
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'Por favor completa todos los campos.',
            confirmButtonText: 'OK'
        });
        return; // Detener si los campos no están completos
    }

    // Enviar los datos al servidor usando Fetch API
    fetch('save_vacuna.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: `codigo_mascota=${encodeURIComponent(codigoMascota)}&fecha_vacunacion=${encodeURIComponent(fechaVacunacion)}&enfermedad=${encodeURIComponent(enfermedad)}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            Swal.fire({
                icon: 'success',
                title: 'Guardado',
                text: 'Los datos se guardaron correctamente',
                confirmButtonText: 'OK',
                showClass: {
                    popup: 'animate__animated animate__fadeInDown'
                },
                hideClass: {
                    popup: 'animate__animated animate__fadeOutUp'
                }
            });
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Hubo un problema al guardar los datos: ' + data.message,
                confirmButtonText: 'OK'
            });
        }
    })
    .catch(error => {
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'No se pudo conectar con el servidor: ' + error,
            confirmButtonText: 'OK'
        });
    });
}

function showCancelAlert() {
    window.location.href = 'home.php';
}

function openSearchModal() {
    const codigoMascota = document.getElementById('codigo-mascota').value;
    
    // Buscar los datos de vacunación asociados al código de mascota
    fetch(`search_vacuna.php?codigo_mascota=${codigoMascota}`)
    .then(response => response.text())
    .then(data => {
        Swal.fire({
            title: 'Resultados de búsqueda',
            html: data,
            confirmButtonText: 'Cerrar'
        });
    })
    .catch(error => {
        Swal.fire('Error', 'No se pudieron obtener los datos', 'error');
    });
}
