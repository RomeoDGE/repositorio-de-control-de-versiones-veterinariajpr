<?php
session_start();

// Verificar si el usuario está autenticado
if (!isset($_SESSION['autenticado']) || $_SESSION['autenticado'] !== true) {
    header("Location: index.php");
    exit;
}

include '../procesos/conexion.php';

if (isset($_POST['delete_consulta_id'])) {
    $id_consulta = $_POST['delete_consulta_id'];
    $sql_delete = "DELETE FROM consultas WHERE id = ?";

    if ($stmt = $mysqli->prepare($sql_delete)) {
        $stmt->bind_param("i", $id_consulta);
        if ($stmt->execute()) {
            // Redirigir con parámetro de éxito
            header("Location: ver_consultas.php?status=success");
            exit;
        } else {
            // Redirigir con parámetro de error
            header("Location: ver_consultas.php?status=error");
            exit;
        }
        $stmt->close();
    } else {
        // Redirigir con parámetro de error
        header("Location: ver_consultas.php?status=error");
        exit;
    }
}

if ($mysqli->connect_error) {
    die("Error de conexión: " . $mysqli->connect_error);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="styles.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <title>Ver Consultas</title>
    <style>
        body {
            background-color: #0cd4da;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .consulta-box {
            width: 800px;
            background-color: #FFF;
            padding: 20px;
            border-radius: 15px;
            text-align: center;
        }
        .banner {
            background-color: #019972;
            color: white;
            padding: 10px;
            border-radius: 5px;
            font-size: 24px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .banner img {
            width: 50px;
        }
        .table-container {
            margin-top: 20px;
            overflow-x: auto;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        th, td {
            border: 1px solid #555;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #b00060;
            color: white;
        }
        .back-button {
            position: absolute;
            top: 20px;
            left: 20px;
            cursor: pointer;
            padding: 10px;
        }
        .delete-button {
            background-color: #d33;
            color: white;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
            border-radius: 5px;
        }
        .search-form input[type="text"] {
        padding: 10px;
        border-radius: 5px;
        border: 1px solid #ccc;
        font-size: 16px;
        width: 200px;
    }
    .search-form button {
        background-color: #019972; /* Color de fondo acorde con el banner */
        color: white;
        border: none;
        padding: 10px 20px;
        border-radius: 5px;
        cursor: pointer;
        font-size: 16px;
    }
    .search-form button:hover {
        background-color: #017c63; /* Color más oscuro para el hover */
    }
    </style>
</head>
<body>
    <a href="javascript:history.back()" class="back-button">
        <svg width="45" height="45" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
            <path d="M512 256A256 256 0 1 0 0 256a256 256 0 1 0 512 0zM217.4 376.9L117.5 269.8c-3.5-3.8-5.5-8.7-5.5-13.8s2-10.1 5.5-13.8l99.9-107.1c4.2-4.5 10.1-7.1 16.3-7.1c12.3 0 22.3 10 22.3 22.3l0 57.7 96 0c17.7 0 32 14.3 32 32l0 32c0 17.7-14.3 32-32 32l-96 0 0 57.7c0 12.3-10 22.3-22.3 22.3c-6.2 0-12.1-2.6-16.3-7.1z"/>
        </svg>
    </a>
    <div class="container">
        <div class="consulta-box">
            <div class="banner">
                <img src="../imgvet/consultas.svg" alt="Logo Izquierdo">
                Historial de Consultas
                <img src="../imgvet/consultas.svg" alt="Logo Derecho">
            </div>
            <div class="search-form">
                <form method="GET" action=""><br>
                    <input type="text" name="search" placeholder="Buscar por código de mascota">
                    <button type="submit" class="btn btn-light btn-lg btn-custom">Buscar</button>
                </form>
            </div>
            <div class="table-container">
                <?php
                $sql = "SELECT c.id, c.sintomas, c.diagnostico, c.tratamiento, c.fecha, m.codigo_mascota
                        FROM consultas c
                        INNER JOIN mascotas m ON c.codigo_mascota = m.codigo_mascota";

                if (isset($_GET['search'])) {
                    $searchTerm = $_GET['search'];
                    $sql .= " WHERE m.codigo_mascota LIKE '%$searchTerm%'";
                }

                if ($result = $mysqli->query($sql)) {
                    if ($result->num_rows > 0) {
                        echo '<table>';
                        echo '<tr><th>ID Consulta</th><th>Síntomas</th><th>Diagnóstico</th><th>Tratamiento</th><th>Fecha</th><th>Codigo Mascota</th><th>Acciones</th></tr>';
                        while ($row = $result->fetch_assoc()) {
                            echo '<tr>';
                            echo '<td>' . htmlspecialchars($row['id']) . '</td>';
                            echo '<td>' . htmlspecialchars($row['sintomas']) . '</td>';
                            echo '<td>' . htmlspecialchars($row['diagnostico']) . '</td>';
                            echo '<td>' . htmlspecialchars($row['tratamiento']) . '</td>';
                            echo '<td>' . htmlspecialchars($row['fecha']) . '</td>';
                            echo '<td>' . htmlspecialchars($row['codigo_mascota']) . '</td>';
                            echo '<td>';
                            echo '<form method="POST" action="" class="delete-form">';
                            echo '<input type="hidden" name="delete_consulta_id" value="' . htmlspecialchars($row['id']) . '">';
                            echo '<button type="button" class="delete-button" onclick="confirmDelete(this)">Eliminar</button>';
                            echo '</form>';
                            echo '</td>';
                            echo '</tr>';
                        }
                        echo '</table>';
                    } else {
                        echo '<p>No hay consultas disponibles.</p>';
                    }
                } else {
                    echo '<p>Error al ejecutar la consulta SQL: ' . $mysqli->error . '</p>';
                }

                $mysqli->close();
                ?>
            </div>
        </div>
    </div>

    <script>
        function confirmDelete(button) {
            Swal.fire({
                title: "¿Estás seguro?",
                text: "Esta acción eliminará la consulta de manera permanente.",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#3085d6",
                cancelButtonColor: "#d33",
                confirmButtonText: "Sí, eliminar",
                cancelButtonText: "Cancelar"
            }).then((result) => {
                if (result.isConfirmed) {
                    // Si el usuario confirma, enviar el formulario
                    button.closest("form").submit();
                }
            });
        }

        // Mostrar la alerta basado en el parámetro de la URL
        const urlParams = new URLSearchParams(window.location.search);
        const status = urlParams.get('status');

        if (status === 'success') {
            Swal.fire({
                icon: "success",
                title: "Consulta Eliminada",
                text: "La consulta se ha eliminado exitosamente",
                showConfirmButton: true
            }).then(() => {
                window.history.replaceState(null, null, window.location.pathname);
            });
        } else if (status === 'error') {
            Swal.fire({
                icon: "error",
                title: "Error",
                text: "No se pudo eliminar la consulta",
                showConfirmButton: true
            }).then(() => {
                window.history.replaceState(null, null, window.location.pathname);
            });
        }
    </script>
</body>
</html>
