// Mostrar alerta de cancelación
function showCancelAlert() {
    Swal.fire({
        icon: 'warning',
        title: '¡Atención!',
        text: 'Los datos no se guardarán.',
        showConfirmButton: true,
        confirmButtonText: 'Entendido'
    });
}

// Mostrar alerta de guardado
function showSaveAlert() {
    Swal.fire({
        icon: 'question',
        title: 'Confirmar Guardado',
        text: '¿Estás seguro de guardar los datos?',
        showCancelButton: true,
        confirmButtonText: 'Sí, guardar',
        cancelButtonText: 'Cancelar'
    });
}

// Abrir modal de búsqueda
function openSearchModal() {
    Swal.fire({
        title: 'Buscar Información',
        html: '<input type="text" id="search-input" class="swal2-input" placeholder="Código de Mascota">',
        showCancelButton: true,
        confirmButtonText: 'Buscar',
        cancelButtonText: 'Cancelar',
        preConfirm: () => {
            const searchValue = Swal.getPopup().querySelector('#search-input').value;
            if (!searchValue) {
                Swal.showValidationMessage('Por favor ingrese un código');
            } else {
                return searchValue;
            }
        }
    }).then((result) => {
        if (result.isConfirmed) {
            Swal.fire(`Buscando información para el código: ${result.value}`);
        }
    });
}

// Abrir selector de fecha
function openDatePicker() {
    flatpickr("#fecha-cita", {
        dateFormat: "d/m/Y",
        defaultDate: "today",
        onClose: function(selectedDates, dateStr, instance) {
            document.getElementById("fecha-cita").value = dateStr;
        }
    }).open();
}

// Abrir selector de hora
function openTimePicker() {
    flatpickr("#hora-cita", {
        enableTime: true,
        noCalendar: true,
        dateFormat: "H:i",
        time_24hr: true,
        onClose: function(selectedDates, dateStr, instance) {
            document.getElementById("hora-cita").value = dateStr;
        }
    }).open();
}

