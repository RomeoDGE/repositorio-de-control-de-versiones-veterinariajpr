<?php
$servername = "localhost";
$username = "uhdflbft_bdveterinaria";  // Cambia esto según tu configuración
$password = "Ejr82tgDNy66Y6Ga7ah7";  // Cambia esto según tu configuración
$dbname = "uhdflbft_bdveterinaria";  // Cambia esto según el nombre de tu base de datos

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener los datos del formulario
$nombre = $_POST['nombre'];
$apaterno = $_POST['apaterno'];
$amaterno = $_POST['amaterno'];
$numcuentbanc = $_POST['numcuentbanc'];
$direccion = $_POST['direccion'];
$telefono = $_POST['telefono'];
$correo = $_POST['correo'];
$codigopost = $_POST['codigopost'];
$rfc = $_POST['rfc'];

// Insertar datos en la tabla Cliente
$sql = "INSERT INTO Cliente (NumCuentBanc, Direccion, Telefono, Correo, CodigoPost, RFC, Nombre, APaterno, AMaterno) 
        VALUES ('$numcuentbanc', '$direccion', '$telefono', '$correo', '$codigopost', '$rfc', '$nombre', '$apaterno', '$amaterno')";

if ($conn->query($sql) === TRUE) {
    echo "Registro de cliente exitoso";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
