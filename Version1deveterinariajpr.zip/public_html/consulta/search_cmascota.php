<?php
// Conexión a la base de datos
$conn = new mysqli("localhost", "uhdflbft_bdveterinaria", "Ejr82tgDNy66Y6Ga7ah7", "uhdflbft_bdveterinaria");

// Verificar la conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

$clave_masc = $_POST['clave_masc'];

// Consultar los datos de la tabla consultas
$sql = "SELECT sintomas, diagnostico, tratamiento FROM consultas WHERE clave_masc = '$clave_masc'";
$result = $conn->query($sql);

$data = [];

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
}

echo json_encode($data);

// Cerrar la conexión
$conn->close();
?>
