// Manejar el evento de búsqueda cuando se presiona el botón de búsqueda
document.getElementById('searchForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevenir el envío del formulario

    const claveMasc = document.getElementById('cclave_masc-buscar').value;

    fetch('search_cmascota.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `clave_masc=${claveMasc}`,
    })
    .then(response => response.json())
    .then(data => {
        const tbody = document.querySelector('#resultsTable tbody');
        tbody.innerHTML = ''; // Limpiar la tabla

        if (data.length > 0) {
            data.forEach(row => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${row.sintomas}</td>
                    <td>${row.diagnostico}</td>
                    <td>${row.tratamiento}</td>
                `;
                tbody.appendChild(tr);
            });
        } else {
            const tr = document.createElement('tr');
            tr.innerHTML = `<td colspan="3">No se encontraron resultados</td>`;
            tbody.appendChild(tr);
        }

        // Mostrar el modal
        document.getElementById('modal').style.display = 'block';
    });
});

// Cerrar el modal cuando se presiona la "X" o fuera del modal
document.getElementById('closeModal').addEventListener('click', function() {
    document.getElementById('modal').style.display = 'none';
});

window.onclick = function(event) {
    if (event.target == document.getElementById('modal')) {
        document.getElementById('modal').style.display = 'none';
    }
};

// Manejar el evento de guardar cuando se presiona el botón de guardar
document.getElementById('saveBtn').addEventListener('click', function(event) {
    event.preventDefault(); // Prevenir comportamiento por defecto del botón

    const claveMasc = document.getElementById('cclave_masc-buscar').value;
    const sintomas = document.getElementById('sintomas').value.trim();
    const diagnostico = document.getElementById('diagnostico').value.trim();
    const tratamiento = document.getElementById('tratamiento').value.trim();

    // Validar que los campos no estén vacíos
    if (!sintomas || !diagnostico || !tratamiento) {
        Swal.fire({
            icon: 'warning',
            title: 'Campos vacíos',
            text: 'Por favor, completa todos los campos antes de guardar.',
            confirmButtonText: 'OK'
        });
        return;
    }

    // Mostrar animación de carga mientras se envían los datos
    Swal.fire({
        title: 'Guardando...',
        text: 'Por favor, espera',
        allowOutsideClick: false,
        showConfirmButton: false,
        willOpen: () => {
            Swal.showLoading();
        }
    });

    // Enviar los datos al servidor mediante fetch
    fetch('guardar_consulta.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `clave_masc=${claveMasc}&sintomas=${sintomas}&diagnostico=${diagnostico}&tratamiento=${tratamiento}`,
    })
    .then(response => response.json())
    .then(data => {
        Swal.close(); // Cerrar la animación de carga

        if (data.success) {
            Swal.fire({
                icon: 'success',
                title: 'Guardado',
                text: 'Los datos se guardaron correctamente',
                confirmButtonText: 'OK',
                showClass: {
                    popup: 'animate__animated animate__fadeInDown'
                },
                hideClass: {
                    popup: 'animate__animated animate__fadeOutUp'
                }
            });
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Hubo un problema al guardar los datos',
                confirmButtonText: 'OK'
            });
        }
    })
    .catch(error => {
        Swal.close(); // Cerrar la animación de carga
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'No se pudo conectar con el servidor',
            confirmButtonText: 'OK'
        });
    });
});
