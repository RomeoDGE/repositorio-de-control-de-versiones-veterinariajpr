<?php
    session_start();
    
    // Verificar si el usuario está autenticado
    if (!isset($_SESSION['autenticado']) || $_SESSION['autenticado'] !== true) {
        // Si no está autenticado, redirigir al login
        header("Location: ./procesos/login.php");
        exit;
    }
    ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consultas</title>
    <link rel="stylesheet" href="../consulta/styles_consulta.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="manifest" href="/manifest.json">
</head>
<body>
    <div class="container">
        <div class="header">
            <span class="icon vet-icon">👩‍⚕️</span>
            <h2>VETERINARIO</h2> 
        </div>
        <div class="content">
            <form id="searchForm">
                <label for="clave_masc-buscar">Código Mascota</label>
                <input type="text" id="clave_masc-buscar" name="codigo_mascota" class="text-input" required>
            </form>

            <label for="sintomas">Síntomas</label>
            <textarea id="sintomas" name="sintomas"></textarea>
            
            <label for="diagnostico">Diagnóstico</label>
            <textarea id="diagnostico" name="diagnostico"></textarea>
            
            <label for="tratamiento">Tratamiento</label>
            <textarea id="tratamiento" name="tratamiento"></textarea>
        </div>

        <div class="buttons">
            <a href="../home.php" class="btn cancel">↩️</a>
            <button class="btn save" id="saveBtn">💾</button>
        </div>
    </div>

    <!-- Modal -->
    <div id="modal" class="modal">
        <div class="modal-content">
            <span id="closeModal" class="close">&times;</span>
            <h2>Resultados de la búsqueda</h2>
            <table id="resultsTable">
                <thead>
                    <tr>
                        <th>Síntomas</th>
                        <th>Diagnóstico</th>
                        <th>Tratamiento</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Aquí se insertarán las filas de la tabla dinámicamente -->
                </tbody>
            </table>
        </div>
    </div>

    <script src="scripts_consulta.js"></script>
    <script>
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.register('/service-worker.js')
            .then(registration => {
                console.log('Service Worker registrado con éxito:', registration.scope);
            })
            .catch(error => {
                console.log('Registro de Service Worker fallido:', error);
            });
        }

    document.getElementById('saveBtn').addEventListener('click', function(event) {
    event.preventDefault();

    // Recoge los datos del formulario
    const codigoMascota = document.getElementById('clave_masc-buscar').value;
    const sintomas = document.getElementById('sintomas').value;
    const diagnostico = document.getElementById('diagnostico').value;
    const tratamiento = document.getElementById('tratamiento').value;

    // Realiza la solicitud AJAX para guardar la consulta
    fetch('guardar_consulta.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: `codigo_mascota=${codigoMascota}&sintomas=${sintomas}&diagnostico=${diagnostico}&tratamiento=${tratamiento}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            Swal.fire({
                icon: 'success',
                title: 'Consulta guardada',
                text: 'La consulta se ha guardado correctamente'
            });

            // Limpiar el formulario
            document.getElementById('clave_masc-buscar').value = '';
            document.getElementById('sintomas').value = '';
            document.getElementById('diagnostico').value = '';
            document.getElementById('tratamiento').value = '';
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: data.message
            });
        }
    })
    .catch(error => {
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'Hubo un problema al guardar los datos'
        });
    });
});


    </script>
</body>
</html>
