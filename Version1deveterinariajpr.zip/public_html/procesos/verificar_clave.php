<?php
// Conexión a la base de datos
$servername = "localhost";
$username = "uhdflbft_bdveterinaria";
$password = "Ejr82tgDNy66Y6Ga7ah7";  // Cambia esto si tienes una contraseña configurada
$dbname = "uhdflbft_bdveterinaria";  // Nombre de tu base de datos

$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Error en la conexión: " . $conn->connect_error);
}

// Obtener la clave secreta enviada desde el formulario
$clave_secreta = $_POST['clave'];

// Preparar la consulta SQL para verificar la clave secreta
$sql = "SELECT * FROM claves_secretas WHERE clave = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $clave_secreta);
$stmt->execute();
$result = $stmt->get_result();

// Verificar si se encontró la clave
if ($result->num_rows > 0) {
    // Clave válida
    echo json_encode(["status" => "success", "message" => "Clave Verificada"]);
} else {
    // Clave inválida
    echo json_encode(["status" => "error", "message" => "Clave Inválida"]);
}

$stmt->close();
$conn->close();
?>
