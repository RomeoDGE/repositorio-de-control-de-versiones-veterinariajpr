<?php
$servername = "localhost";
$username = "uhdflbft_bdveterinaria";
$password = "Ejr82tgDNy66Y6Ga7ah7";
$dbname = "uhdflbft_bdveterinaria";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$codigoMascotaBuscar = $_POST['codigo_mascota'];

$sql = "SELECT codigo_mascota, fecha_vacuna, enfermedad FROM calendario_vacunacion WHERE codigo_mascota = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $codigoMascotaBuscar);
$stmt->execute();
$stmt->bind_result($codigoMascota, $fechaVacuna, $enfermedad);
$stmt->fetch();

$response = array(
    "codigo_mascota" => $codigoMascota,
    "fecha_vacuna" => $fechaVacuna,
    "enfermedad" => $enfermedad
);

$stmt->close();
$conn->close();

echo json_encode($response);
?>
