<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Historial Médico</title>
    <link rel="stylesheet" href="../styles/stylesC.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        .back-button {
            position: absolute;
            top: 20px; /* Ajusta la posición superior según tu diseño */
            left: 20px; /* Ajusta la posición izquierda según tu diseño */
            cursor: pointer;
            padding: 10px; /* Agrega un relleno al botón para darle más espacio */
        }
    </style>
</head>
<body>
<a href="javascript:history.back()" class="back-button">
        <svg width="45" height="45" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
            <path d="M512 256A256 256 0 1 0 0 256a256 256 0 1 0 512 0zM217.4 376.9L117.5 269.8c-3.5-3.8-5.5-8.7-5.5-13.8s2-10.1 5.5-13.8l99.9-107.1c4.2-4.5 10.1-7.1 16.3-7.1c12.3 0 22.3 10 22.3 22.3l0 57.7 96 0c17.7 0 32 14.3 32 32l0 32c0 17.7-14.3 32-32 32l-96 0 0 57.7c0 12.3-10 22.3-22.3 22.3c-6.2 0-12.1-2.6-16.3-7.1z"/>
        </svg>
    </a>
    <div class="container">
        <div class="header">
            <h2>Historial Médico</h2>
        </div>
        <div class="search-section">
            <label for="codigo-mascota">Codigo Mascota</label>
            <input type="text" id="codigo-mascota">
            <button id="buscar-btn">
                <img src="search-icon.png" alt="Buscar" />
            </button>
        </div>
        <table id="tabla-historial">
            <thead>
                <tr>
                    <th>Alias</th>
                    <th>Fecha</th>
                    <th>Enfermedad</th>
                </tr>
            </thead>
            <tbody>
                <!-- Aquí se desplegarán los datos -->
            </tbody>
        </table>
        <button id="back-btn" class="back-btn">↩</button>
    </div>

    <!-- Modal -->
    <div id="modal" class="modal">
        <div class="modal-content">
            <span id="close-modal" class="close">&times;</span>
            <h2>Buscar Información</h2>
            <input type="text" id="input-buscar">
            <button id="seleccionar-btn">Seleccionar</button>
        </div>
    </div>

    <script src="../scripts/scripts.js"></script>
</body>
</html>
