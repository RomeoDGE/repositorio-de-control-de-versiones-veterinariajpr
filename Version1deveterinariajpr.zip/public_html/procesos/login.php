<?php
session_start();
header('Content-Type: application/json'); // Asegúrate de que se envíe JSON

$servername = "localhost";
$username = "uhdflbft_bdveterinaria";
$password = "Ejr82tgDNy66Y6Ga7ah7";
$dbname = "uhdflbft_bdveterinaria";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    echo json_encode(["status" => "error", "message" => "Error de conexión: " . $conn->connect_error]);
    exit();
}

// Obtener los datos del formulario
$usuario = $_POST['usuario'];
$contrasena = $_POST['contrasena'];

// Buscar el usuario en la base de datos
$sql = "SELECT * FROM veterinario WHERE usuario = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $usuario);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if ($user && password_verify($contrasena, $user['contrasena'])) {
    // Usuario autenticado correctamente
    $_SESSION['usuario'] = $usuario;
    $_SESSION['autenticado'] = true; // Añadir esta línea
    echo json_encode(["status" => "success", "message" => "Inicio de sesión exitoso. ¡Bienvenido, $usuario!"]);
} else {
    // Error de autenticación
    echo json_encode(["status" => "error", "message" => "Usuario o contraseña incorrectos."]);
}


$conn->close();
?>
