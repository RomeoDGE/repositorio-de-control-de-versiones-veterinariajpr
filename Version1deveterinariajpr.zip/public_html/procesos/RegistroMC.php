<?php
// Mostrar todos los errores y advertencias
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Incluye el archivo de conexión
include 'conexion.php';

session_start(); // Inicia la sesión

if (!isset($_SESSION['autenticado']) || $_SESSION['autenticado'] !== true) {
    // Redirigir a la página de inicio de sesión
    header('Location: ../index.php');
    exit;
}

$showClienteAlert = false;
$showMascotaAlert = false;

// Procesar el registro de clientes
if (isset($_POST["cliente_submit"])) {
    $codigo_cliente = $_POST["codigo_cliente"];
    $numero_cuenta = $_POST["numero_cuenta"];
    $direccion = $_POST["direccion"];
    $telefono = $_POST["telefono"];
    $correo = $_POST["correo"];
    $codigo_postal = $_POST["codigo_postal"];
    $rfc = $_POST["rfc"];
    $nombre_completo = $_POST["nombre_completo"];


    // Consulta SQL para verificar si el código del cliente ya existe
    $sql = "SELECT Codigo_Cliente FROM clientes WHERE Codigo_Cliente = ?";
    if ($stmt = $mysqli->prepare($sql)) {
        $stmt->bind_param("s", $codigo_cliente);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            // Código de cliente ya existe en la base de datos, muestra un mensaje de error
            echo '<script>
                    document.addEventListener("DOMContentLoaded", function() {
                        Swal.fire({
                            icon: "error",
                            title: "El código del cliente ya existe en la base de datos",
                            showConfirmButton: false,
                            timer: 1500
                        });
                    });
                </script>';
        } else {
            // El código de cliente no existe, procede con la inserción
            $sql = "INSERT INTO clientes (Codigo_Cliente, Numero_Cuenta, Direccion, Telefono, Correo, Codigo_Postal, RFC, Nombre_Completo) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            if ($stmt = $mysqli->prepare($sql)) {
                $stmt->bind_param("ssssssss", $codigo_cliente, $numero_cuenta, $direccion, $telefono, $correo, $codigo_postal, $rfc, $nombre_completo);

                if ($stmt->execute()) {
                    // Éxito en la inserción
                    echo '<script>
                            document.addEventListener("DOMContentLoaded", function() {
                                Swal.fire({
                                    icon: "success",
                                    title: "Registro de cliente exitoso!",
                                    showConfirmButton: false,
                                    timer: 1500
                                }).then(function() {
                                    window.location = "RegistroMC.php"; // Redirige después de cerrar la alerta
                                });
                            });
                        </script>';
                } else {
                    echo 'Error al registrar el cliente: ' . $mysqli->error;
                }
            }
        }
    }
}

// Procesar el registro de mascotas
if (isset($_POST["mascota_submit"])) {
    $codigo_cliente = $_POST["codigo_cliente"];
    $codigo_mascota = $_POST["codigo_mascota"];

    // Consulta SQL para verificar si el código del cliente existe
    $sql = "SELECT Codigo_Cliente FROM clientes WHERE Codigo_Cliente = ?";
    if ($stmt = $mysqli->prepare($sql)) {
        $stmt->bind_param("s", $codigo_cliente);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows === 0) {
            // Código del cliente no existe, muestra un mensaje de error
            echo '<script>
                    document.addEventListener("DOMContentLoaded", function() {
                        Swal.fire({
                            icon: "error",
                            title: "Código del cliente inexistente",
                            showConfirmButton: false,
                            timer: 1500
                        });
                    });
                </script>';
        } else {
            // Código del cliente existe, procede con la verificación de código de mascota
            $sql = "SELECT Codigo_Mascota FROM mascotas WHERE Codigo_Mascota = ?";
            if ($stmt = $mysqli->prepare($sql)) {
                $stmt->bind_param("s", $codigo_mascota);
                $stmt->execute();
                $stmt->store_result();
                if ($stmt->num_rows > 0) {
                    // Código de la mascota ya existe, muestra un mensaje de error
                    echo '<script>
                            document.addEventListener("DOMContentLoaded", function() {
                                Swal.fire({
                                    icon: "error",
                                    title: "Código de la mascota ya existe",
                                    showConfirmButton: false,
                                    timer: 1500
                                });
                            });
                        </script>';
                } else {
                    // Código de la mascota no existe, procede con la inserción
                    $alias = $_POST["alias"];
                    $especie = $_POST["especie"];
                    $raza = $_POST["raza"];
                    $color_pelo = $_POST["color_pelo"];
                    $fecha_nacimiento = $_POST["fecha_nacimiento"];
                    $peso_medio = $_POST["peso_medio"];
                    $peso_actual = $_POST["peso_actual"];

                    // Consulta SQL para insertar datos en la tabla de mascotas
                    $sql = "INSERT INTO mascotas (Codigo_Mascota, Alias, Especie, Raza, Color_Pelo, Fecha_Nacimiento, Peso_Medio, Peso_Actual, Codigo_Cliente) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
                    if ($stmt = $mysqli->prepare($sql)) {
                        $stmt->bind_param("sssssssss", $codigo_mascota, $alias, $especie, $raza, $color_pelo, $fecha_nacimiento, $peso_medio, $peso_actual, $codigo_cliente);

                        if ($stmt->execute()) {
                            // Éxito en la inserción
                            echo '<script>
                                    document.addEventListener("DOMContentLoaded", function() {
                                        Swal.fire({
                                            icon: "success",
                                            title: "Registro de mascota exitoso!",
                                            showConfirmButton: false,
                                            timer: 1500
                                        }).then(function() {
                                            window.location = "../home.php"; // Redirige después de cerrar la alerta
                                        });
                                    });
                                </script>';
                        } else {
                            echo 'Error al registrar la mascota: ' . $mysqli->error;
                        }
                    }
                }
            }
        }
    }
}

?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="styles.css">
    <meta charset="UTF-8">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    
    <title>Registro de Clientes y Mascotas</title>
    <script>
        if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('service-worker.js')
      .then((registration) => {
        console.log('Service Worker registrado con éxito:', registration);
      })
      .catch((error) => {
        console.log('Error al registrar el Service Worker:', error);
      });
  }
    </script>
    <style>
        /* Estilos generales de la página */
        body {
            background-color: #0cd4da;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            margin: 20px;
        }

        .form {
            background-color: white;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            width: 45%;
            margin-bottom: 20px;
        }

        .form label, .form input, .form select {
            display: block;
            margin-bottom: 10px;
        }

        .form label {
            font-weight: bold;
        }

        .form input, .form select {
            width: 100%;
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }

        .form button {
            background-color: #b00060;
            color: white;
            padding: 15px 15px;
            border: none;
            cursor: pointer;
        }

        /* Estilos del botón "Salir" */
        .back-button {
            top: 20px;
            left: 20px;
            cursor: pointer;
            padding: 10px;
        }
        .banner {
            background-color: #019972;
            color: white;
            padding: 5px;
            border-radius: 5px;
            font-size: 14px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .banner img {
            width: 50px;
        }

        /* Estilos para pantallas más pequeñas (menos de 768px) */
        @media (max-width: 768px) {
            .container {
                flex-direction: column;
                width: 100%;
                margin-bottom: 20px;
            }
        }
    </style>
</head>
<body>
    <!-- Botón "Salir" para regresar a la página anterior -->
    <a href="javascript:history.back()" class="back-button">
        <svg width="45" height="45" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
            <path d="M512 256A256 256 0 1 0 0 256a256 256 0 1 0 512 0zM217.4 376.9L117.5 269.8c-3.5-3.8-5.5-8.7-5.5-13.8s2-10.1 5.5-13.8l99.9-107.1c4.2-4.5 10.1-7.1 16.3-7.1c12.3 0 22.3 10 22.3 22.3l0 57.7 96 0c17.7 0 32 14.3 32 32l0 32c0 17.7-14.3 32-32 32l-96 0 0 57.7c0 12.3-10 22.3-22.3 22.3c-6.2 0-12.1-2.6-16.3-7.1z"/>
        </svg>
    </a>

    <!-- Contenedor principal con dos formularios -->
    <div class="container">
        <!-- Formulario de Registro de Clientes -->
        <div class="form">
        <div class="banner">
        <img src="../imgvet/cliente.png" class="left-logo" alt="Logo Izquierdo">
            <h2>Registro de Clientes</h2>
        <img src="../imgvet/cliente.png" class="right-logo" alt="Logo Derecho">
        </div>
            <form id="clienteForm" method="post" action="">

                <label for="codigo_cliente">Codigo del Cliente:</label>
                <input type="text" id="codigo_cliente" name="codigo_cliente" required>

                <label for="numero_cuenta">Número de Cuenta:</label>
                <input type="text" id="numero_cuenta" name="numero_cuenta" required>

                <label for="direccion">Dirección:</label>
                <input type="text" id="direccion" name="direccion" required>

                <label for="telefono">Teléfono:</label>
                <input type="text" id="telefono" name="telefono" required>

                <label for="correo">Correo Electrónico:</label>
                <input type="email" id="correo" name="correo" required>

                <label for="codigo_postal">Código Postal:</label>
                <input type="text" id="codigo_postal" name="codigo_postal" required>

                <label for="rfc">RFC:</label>
                <input type="text" id="rfc" name="rfc" required>

                <label for="nombre_completo">Nombre Completo (Apellido Paterno, Apellido Materno y Nombre):</label>
                <input type="text" id="nombre_completo" name="nombre_completo" required>

                <button id="guardarButton" name="cliente_submit" class="btn btn-light btn-lg btn-custom">Registrar Cliente</button>
            </form>
        </div>

        <!-- Formulario de Registro de Mascotas -->
        <div class="form">
        <div class="banner">
        <img src="../imgvet/icondog.png" class="left-logo" alt="Logo Izquierdo">
            <h2>Registro de Mascotas</h2>
        <img src="../imgvet/iconcat.svg" class="right-logo" alt="Logo Derecho">
        </div>
            <form id="mascotaForm" method="post" action="">
                <label for="codigo_mascota">Código de la Mascota:</label>
                <input type="text" id="codigo_mascota" name="codigo_mascota" required>

                <label for="alias">Alias:</label>
                <input type="text" id="alias" name="alias" required>

                <label for="especie">Especie:</label>
                <input type="text" id="especie" name="especie" required>

                <label for="raza">Raza:</label>
                <input type="text" id="raza" name="raza" required>

                <label for="color_pelo">Color de Pelo:</label>
                <input type="text" id="color_pelo" name="color_pelo" required>

                <label for="fecha_nacimiento">Fecha de Nacimiento:</label>
                <input type="date" id="fecha_nacimiento" name="fecha_nacimiento" required>

                <label for="peso_medio">Peso Medio (últimas 10 visitas, en números):</label>
                <input type="text" id="peso_medio" name="peso_medio" required>

                <label for="peso_actual">Peso Actual  (en números):</label>
                <input type="text" id="peso_actual" name="peso_actual" required>

                <label for="codigo_cliente">Código del Cliente:</label>
                <input type="text" id="codigo_cliente" name="codigo_cliente" required>

                <button id="guardarButton" name="mascota_submit" class="btn btn-light btn-lg btn-custom">Registrar Mascota</button>
            </form>
        </div>
    </div>
</body>
</html>

