<?php
session_start();

// Verificar si el usuario está autenticado
if (!isset($_SESSION['autenticado']) || $_SESSION['autenticado'] !== true) {
    // Si no está autenticado, redirigir al login
    header("Location: index.php");
    exit;
}

// Procesar la eliminación de clientes
if (isset($_POST['eliminar_cliente'])) {
    include '../procesos/conexion.php'; // Incluye el archivo de conexión a la base de datos

    $codigo_cliente = $_POST['codigo_cliente'];

    // Iniciar una transacción
    $mysqli->begin_transaction();

    try {
        // Eliminar mascotas asociadas
        $sql_mascotas = "DELETE FROM mascotas WHERE Codigo_Cliente = ?";
        if ($stmt_mascotas = $mysqli->prepare($sql_mascotas)) {
            $stmt_mascotas->bind_param("s", $codigo_cliente);
            $stmt_mascotas->execute();
            $stmt_mascotas->close();
        }

        // Eliminar el cliente
        $sql_cliente = "DELETE FROM clientes WHERE Codigo_Cliente = ?";
        if ($stmt_cliente = $mysqli->prepare($sql_cliente)) {
            $stmt_cliente->bind_param("s", $codigo_cliente);
            $stmt_cliente->execute();
            $stmt_cliente->close();
        }

        // Confirmar la transacción
        $mysqli->commit();

        echo '<script>
                document.addEventListener("DOMContentLoaded", function() {
                    Swal.fire({
                        icon: "success",
                        title: "Cliente y mascotas eliminados exitosamente",
                        showConfirmButton: false,
                        timer: 1500
                    });
                });
            </script>';
    } catch (Exception $e) {
        // Revertir la transacción en caso de error
        $mysqli->rollback();
        echo '<script>
                document.addEventListener("DOMContentLoaded", function() {
                    Swal.fire({
                        icon: "error",
                        title: "Error al eliminar el cliente y las mascotas",
                        showConfirmButton: false,
                        timer: 1500
                    });
                });
            </script>';
    }

    $mysqli->close();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="styles.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <title>Ver Clientes y Mascotas</title>
    <style>
        body {
            background-color: #0cd4da;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .clientes-box {
            width: 90%;
            max-width: 950px;
            background-color: #FFF;
            padding: 20px;
            border-radius: 15px;
            text-align: center;
            margin-top: 20px;
        }
        .banner {
            background-color: #019972;
            color: white;
            padding: 10px;
            border-radius: 5px;
            font-size: 24px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .banner img {
            width: 50px;
        }
        .table-container {
            overflow-x: auto;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        th, td {
            border: 1px solid #555;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #b00060;
            color: white;
        }
        .back-button {
            top: 20px;
            left: 20px;
            cursor: pointer;
            padding: 10px;
        }
        .delete-form, .print-button {
            margin: 10px 0;
        }
        .delete-form select, .delete-form button, .print-button button {
            padding: 10px;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .delete-form select {
            border: 1px solid #555;
            margin-right: 10px;
        }
        .delete-form select:focus, .delete-form button:hover, .print-button button:hover {
            background-color: #7c3aed;
            color: white;
            transform: scale(1.05);
        }
        .delete-form button {
            background-color: #e63946;
            color: white;
        }
        .delete-form button:active {
            background-color: #d62839;
        }
        @media screen and (max-width: 600px) {
            .buscador-container {
                flex-direction: column;
                align-items: stretch;
            }
        }
    </style>
</head>
<body>
    <a href="javascript:history.back()" class="back-button">
        <svg width="45" height="45" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
            <path d="M512 256A256 256 0 1 0 0 256a256 256 0 1 0 512 0zM217.4 376.9L117.5 269.8c-3.5-3.8-5.5-8.7-5.5-13.8s2-10.1 5.5-13.8l99.9-107.1c4.2-4.5 10.1-7.1 16.3-7.1c12.3 0 22.3 10 22.3 22.3l0 57.7 96 0c17.7 0 32 14.3 32 32l0 32c0 17.7-14.3 32-32 32l-96 0 0 57.7c0 12.3-10 22.3-22.3 22.3c-6.2 0-12.1-2.6-16.3-7.1z"/>
        </svg>
    </a>
    <div class="container">
        <div class="clientes-box">
            <div class="banner">
                <img src="../imgvet/cliente.png" alt="Logo Izquierdo">
                Lista de Clientes y Mascotas
                <img src="../imgvet/cliente.png" alt="Logo Derecho">
            </div>
            <form method="post" class="delete-form">
                <label for="codigo_cliente">Selecciona el Código del Cliente para Eliminar:</label>
                <select id="codigo_cliente" name="codigo_cliente" required>
                    <?php
                    include '../procesos/conexion.php'; // Incluye el archivo de conexión a la base de datos
                    
                    // Obtener todos los códigos de cliente
                    $sql = "SELECT Codigo_Cliente FROM clientes";
                    $result = $mysqli->query($sql);

                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo '<option value="' . $row['Codigo_Cliente'] . '">' . $row['Codigo_Cliente'] . '</option>';
                        }
                    } else {
                        echo '<option value="">No hay códigos disponibles</option>';
                    }

                    $mysqli->close();
                    ?>
                </select>
                <button type="submit" name="eliminar_cliente">Eliminar Cliente</button>
            </form>
            <div class="table-container">
                <?php
                include '../procesos/conexion.php'; // Incluye el archivo de conexión a la base de datos
                
                // Consulta SQL con JOIN para obtener los detalles de todos los clientes y mascotas
                $sql = "SELECT c.Codigo_Cliente, c.Numero_Cuenta, c.Direccion, c.Telefono, c.Correo, c.Codigo_Postal, c.RFC, c.Nombre_Completo, 
                               m.Codigo_Mascota, m.Alias, m.Especie, m.Raza, m.Color_Pelo, m.Fecha_Nacimiento, m.Peso_Medio, m.Peso_Actual
                        FROM clientes c
                        LEFT JOIN mascotas m ON c.Codigo_Cliente = m.Codigo_Cliente";
                $result = $mysqli->query($sql);

                if ($result->num_rows > 0) {
                    ?>
                    <table>
                        <tr>
                            <th>Código Cliente</th>
                            <th>Nombre Completo</th>
                            <th>Dirección</th>
                            <th>Teléfono</th>
                            <th>Correo</th>
                            <th>Código Postal</th>
                            <th>RFC</th>
                            <th>Código Mascota</th>
                            <th>Alias Mascota</th>
                            <th>Especie</th>
                            <th>Raza</th>
                            <th>Color de Pelo</th>
                            <th>Fecha de Nacimiento</th>
                            <th>Peso Medio</th>
                            <th>Peso Actual</th>
                        </tr>
                        <?php
                        while ($row = $result->fetch_assoc()) {
                            ?>
                            <tr>
                                <td><?php echo $row['Codigo_Cliente']; ?></td>
                                <td><?php echo $row['Nombre_Completo']; ?></td>
                                <td><?php echo $row['Direccion']; ?></td>
                                <td><?php echo $row['Telefono']; ?></td>
                                <td><?php echo $row['Correo']; ?></td>
                                <td><?php echo $row['Codigo_Postal']; ?></td>
                                <td><?php echo $row['RFC']; ?></td>
                                <td><?php echo $row['Codigo_Mascota']; ?></td>
                                <td><?php echo $row['Alias']; ?></td>
                                <td><?php echo $row['Especie']; ?></td>
                                <td><?php echo $row['Raza']; ?></td>
                                <td><?php echo $row['Color_Pelo']; ?></td>
                                <td><?php echo $row['Fecha_Nacimiento']; ?></td>
                                <td><?php echo $row['Peso_Medio']; ?></td>
                                <td><?php echo $row['Peso_Actual']; ?></td>
                            </tr>
                            <?php
                        }
                        ?>
                    </table>
                    <?php
                } else {
                    echo '<p>No hay clientes y mascotas registrados.</p>';
                }

                $mysqli->close();
                ?>
            </div>
        </div>
    </div>
    
</body>
</html>
