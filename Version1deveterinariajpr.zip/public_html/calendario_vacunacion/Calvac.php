<?php
session_start();

// Verificar si el usuario está autenticado
if (!isset($_SESSION['autenticado']) || $_SESSION['autenticado'] !== true) {
    header("Location: ./procesos/login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calendario de Vacunación</title>
    <link rel="stylesheet" href="stylescalvac.css">
    <link rel="manifest" href="manifest.json">
</head>
<body>
<div class="container">
    <header class="header">
        <img src="../imgvet/calendar.svg" alt="Logo Izquierdo">
        <h2>CALENDARIO DE VACUNACIÓN</h2>
    </header>

    <main class="content">
        <!-- El formulario ahora enviará los datos directamente a save_vacuna.php -->
        <form action="save_vacuna.php" method="POST" class="form">
            <label for="codigo-mascota">Código Mascota</label>
            <input type="text" id="codigo-mascota" name="codigo_mascota" class="text-input" required>

            <label for="fecha-vacunacion">Fecha de Vacunación</label>
            <input type="date" id="fecha-vacunacion" name="fecha_vacunacion" class="text-input" required>

            <label for="enfermedad">Enfermedad</label>
            <input type="text" id="enfermedad" name="enfermedad" class="text-input" required>
            
            <div class="buttons">
                <!-- Cambiado el tipo de botón a submit para que el formulario se envíe -->
                <button type="submit" class="btn save">💾 Guardar</button>
                <a href="../home.php" class="btn cancel">↩️ Cancelar</a>
            </div>
        </form>

        <div class="search">
            <h3>Buscar Vacunación</h3>
            <form id="searchForm" method="POST" class="form">
                <label for="codigo-mascota-buscar">Código Mascota</label>
                <input type="text" id="codigo-mascota-buscar" name="codigo_mascota" class="text-input" required>
                <button type="button" id="searchButton" class="btn search-btn">🔎</button>
            </form>
        </div>
    </main>

    <!-- Modal -->
    <div id="myModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Información de Vacunación</h2>
            <table id="modalTable">
                <tr>
                    <th>Código Mascota</th>
                    <td id="modalCodigoMascota"></td>
                </tr>
                <tr>
                    <th>Fecha de Vacuna</th>
                    <td id="modalFechaVacuna"></td>
                </tr>
                <tr>
                    <th>Enfermedad</th>
                    <td id="modalEnfermedad"></td>
                </tr>
            </table>
            <button class="modal-btn" id="closeModal">Cerrar</button>
        </div>
    </div>
</div>

<script>
    // Registrar el Service Worker
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('/service-worker.js')
        .then((registration) => {
            console.log('Service Worker registrado con éxito:', registration);
        }).catch((error) => {
            console.log('Error al registrar el Service Worker:', error);
        });
    }

    var modal = document.getElementById("myModal");
    var btn = document.getElementById("searchButton");
    var span = document.getElementsByClassName("close")[0];
    var closeModalBtn = document.getElementById("closeModal");

    btn.onclick = function() {
        var codigoMascota = document.getElementById("codigo-mascota-buscar").value;

        if (codigoMascota) {
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "search_vacuna.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            xhr.onreadystatechange = function() {
                if (this.readyState === XMLHttpRequest.DONE && this.status === 200) {
                    var response = JSON.parse(this.responseText);

                    document.getElementById("modalCodigoMascota").innerText = response.codigo_mascota;
                    document.getElementById("modalFechaVacuna").innerText = response.fecha_vacuna;
                    document.getElementById("modalEnfermedad").innerText = response.enfermedad;

                    modal.style.display = "block";
                }
            }

            xhr.send("codigo_mascota=" + encodeURIComponent(codigoMascota));
        }
    }

    span.onclick = function() {
        modal.style.display = "none";
    }

    closeModalBtn.onclick = function() {
        modal.style.display = "none";
    }

    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }
</script>
<script src="scripts.js"></script>

</body>
</html>
