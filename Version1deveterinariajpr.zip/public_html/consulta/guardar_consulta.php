<?php
header('Content-Type: application/json');

// Configuración de la base de datos
$servername = "localhost";  // Cambia a tu servidor MySQL
$username = "uhdflbft_bdveterinaria";  // Cambia a tu usuario MySQL
$password = "Ejr82tgDNy66Y6Ga7ah7";  // Cambia a tu contraseña MySQL
$dbname = "uhdflbft_bdveterinaria";  // Cambia al nombre de tu base de datos

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Conexión fallida: ' . $conn->connect_error]);
    exit;
}

// Obtener datos del formulario
$codigo_mascota = $_POST['codigo_mascota'];  // Asegúrate de que este campo se envía correctamente
$sintomas = $_POST['sintomas'];
$diagnostico = $_POST['diagnostico'];
$tratamiento = $_POST['tratamiento'];

// Verificar si el código de la mascota existe en la tabla 'mascotas'
$sql_check = "SELECT codigo_mascota FROM mascotas WHERE codigo_mascota = ?";
$stmt_check = $conn->prepare($sql_check);
$stmt_check->bind_param("s", $codigo_mascota);
$stmt_check->execute();
$stmt_check->store_result();

if ($stmt_check->num_rows > 0) {
    // Si la mascota existe, se inserta la consulta
    $sql_insert = "INSERT INTO consultas (codigo_mascota, sintomas, diagnostico, tratamiento) VALUES (?, ?, ?, ?)";
    $stmt_insert = $conn->prepare($sql_insert);
    $stmt_insert->bind_param("ssss", $codigo_mascota, $sintomas, $diagnostico, $tratamiento);

    if ($stmt_insert->execute()) {
        echo json_encode(['success' => true, 'message' => 'Datos guardados correctamente']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error al guardar los datos: ' . $conn->error]);
    }

    $stmt_insert->close();
} else {
    // Si la mascota no existe, mostrar mensaje de error
    echo json_encode(['success' => false, 'message' => 'Error: El código de la mascota no existe']);
}

// Cerrar conexión
$stmt_check->close();
$conn->close();
?>
