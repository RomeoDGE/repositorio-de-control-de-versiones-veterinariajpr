<?php
session_start();

// Verificar si el usuario está autenticado
if (!isset($_SESSION['autenticado']) || $_SESSION['autenticado'] !== true) {
    header("Location: index.php");
    exit;
}

// Incluir el archivo de conexión
include '../procesos/conexion.php';

// Definir una respuesta por defecto
$response = ['status' => 'error', 'message' => 'Error en el procesamiento.'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $codigo_mascota = $_POST['codigo_mascota'];
    $fecha_cita = $_POST['fecha_cita'];
    $hora_cita = $_POST['hora_cita'];

    // Validar datos
    if (empty($codigo_mascota) || empty($fecha_cita) || empty($hora_cita)) {
        $response = ['status' => 'error', 'message' => 'Todos los campos son requeridos'];
        echo json_encode($response);
        exit;
    }

    // Verificar si el código de mascota existe
    $sql_check = "SELECT COUNT(*) FROM mascotas WHERE codigo_mascota = ?";
    if ($stmt_check = $mysqli->prepare($sql_check)) {
        $stmt_check->bind_param("s", $codigo_mascota);
        $stmt_check->execute();
        $stmt_check->bind_result($count);
        $stmt_check->fetch();
        $stmt_check->close();
        
        if ($count == 0) {
            $response = ['status' => 'error', 'message' => 'Código de mascota no existe'];
            echo json_encode($response);
            exit;
        }
    } else {
        $response = ['status' => 'error', 'message' => 'Error en la consulta SQL'];
        echo json_encode($response);
        exit;
    }

    // Preparar y ejecutar la consulta SQL
    $sql = "INSERT INTO agendar_citas (codigo_mascota, fecha_cita, hora_cita) VALUES (?, ?, ?)";
    if ($stmt = $mysqli->prepare($sql)) {
        $stmt->bind_param("sss", $codigo_mascota, $fecha_cita, $hora_cita);
        if ($stmt->execute()) {
            $response = ['status' => 'success', 'message' => 'La cita se ha guardado exitosamente'];
        } else {
            $response = ['status' => 'error', 'message' => 'No se pudo guardar la cita'];
        }
        $stmt->close();
    } else {
        $response = ['status' => 'error', 'message' => 'Error en la consulta SQL'];
    }

    $mysqli->close();
    
    echo json_encode($response);
}
?>
