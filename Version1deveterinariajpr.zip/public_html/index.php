<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro e Inicio de Sesión</title>
    <!-- Incluyendo Bootstrap para estilos responsivos -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles/styles.css">

    <!-- Estilos personalizados -->
    <style>
    </style>
</head>
<body>

<div class="flip-card" id="flipCard">
    <div class="flip-card-inner">
        <!-- Front Side - Login Form -->
        <div class="flip-card-front">
            <h2>Iniciar Sesión</h2>
            <form id="loginForm" action="procesos/login.php" method="POST">
            <div class="form-group">
                <label for="usuario">Usuario:</label>
                <input type="text" class="form-control" id="usuario" name="usuario" required>
            </div>
            <div class="form-group">
                <label for="contrasena">Contraseña:</label>
                <input type="password" class="form-control" id="contrasena" name="contrasena" required>
            </div>
            <button type="submit" class="btn btn-custom btn-block">Iniciar Sesión</button>
        </form>
            <p class="mt-4">
                ¿No tienes cuenta? <a href="#" id="showRegisterForm">Regístrate</a>
            </p>
            <img src="img/gatologin.jpg" width="300px" height="140px" >
        </div>
        <!-- Back Side - Registration Form -->
        <div class="flip-card-back">
            <h2>Registro de Veterinario</h2>
            <form action="procesos/registro_veterinario.php" method="POST">
                <div class="form-group">
                    <label for="usuario_reg">Usuario:</label>
                    <input type="text" class="form-control" id="usuario_reg" name="usuario" required>
                </div>
                <div class="form-group">
                    <label for="contrasena_reg">Contraseña:</label>
                    <input type="password" class="form-control" id="contrasena_reg" name="contrasena" required>
                </div>
                <div class="form-group">
                    <label for="correo_reg">Correo:</label>
                    <input type="email" class="form-control" id="correo_reg" name="correo" required>
                </div>
                <div class="form-group">
                    <label for="nombre_reg">Nombre:</label>
                    <input type="text" class="form-control" id="nombre_reg" name="nombre" required>
                </div>
                <div class="form-group">
                    <label for="apaterno_reg">Apellido Paterno:</label>
                    <input type="text" class="form-control" id="apaterno_reg" name="apaterno" required>
                </div>
                <div class="form-group">
                    <label for="amaterno_reg">Apellido Materno:</label>
                    <input type="text" class="form-control" id="amaterno_reg" name="amaterno">
                </div>
                <button type="submit" class="btn btn-custom btn-block">Registrar Veterinario</button>
            </form>
            <p class="mt-4">
                ¿Ya tienes cuenta? <a href="#" id="showLoginForm">Inicia sesión</a>
            </p>
        </div>
    </div>
</div>

<!-- Modal for Secret Key -->
<div class="modal fade" id="secretKeyModal" tabindex="-1" role="dialog" aria-labelledby="secretKeyModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="secretKeyModalLabel">Verificación de Clave Secreta</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="secretKeyForm">
                    <div class="form-group">
                        <label for="secretKeyInput">Clave Secreta:</label>
                        <input type="password" class="form-control" id="secretKeyInput" placeholder="Ingrese la clave secreta">
                    </div>
                    <button type="button" class="btn btn-primary" id="verifySecretKey">Verificar Clave</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>

<script>
    const flipCard = document.getElementById('flipCard');
    const showRegisterForm = document.getElementById('showRegisterForm');
    const showLoginForm = document.getElementById('showLoginForm');
    const secretKeyModal = new bootstrap.Modal(document.getElementById('secretKeyModal'));
    const secretKeyInput = document.getElementById('secretKeyInput');

    showRegisterForm.addEventListener('click', function(e) {
        e.preventDefault();
        secretKeyModal.show();
    });

    showLoginForm.addEventListener('click', function(e) {
        e.preventDefault();
        flipCard.classList.remove('flip');
    });

    document.getElementById('verifySecretKey').addEventListener('click', function() {
    const secretKey = secretKeyInput.value;

    // Realizar la solicitud AJAX para verificar la clave
    fetch('procesos/verificar_clave.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: `clave=${encodeURIComponent(secretKey)}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === "success") {
            secretKeyModal.hide();
            Swal.fire({
                title: 'Clave Verificada!',
                text: 'Acceso concedido',
                icon: 'success',
                confirmButtonText: 'Aceptar'
            }).then(() => {
                flipCard.classList.add('flip');
            });
        } else {
            Swal.fire({
                title: 'Clave Inválida',
                text: 'Acceso denegado',
                icon: 'error',
                confirmButtonText: 'Aceptar'
            });
        }
    })
    .catch(error => console.error('Error:', error));
});

document.querySelector('form[action="procesos/registro_veterinario.php"]').addEventListener('submit', function(e) {
    e.preventDefault(); // Prevenir el envío del formulario por defecto

    const formData = new FormData(this);

    fetch('procesos/registro_veterinario.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === "success") {
            Swal.fire({
                title: '¡Registro Exitoso!',
                text: data.message,
                icon: 'success',
                confirmButtonText: 'Aceptar'
            }).then(() => {
                // Puedes redirigir al usuario a otra página o resetear el formulario
                window.location.href = 'index.php'; // Por ejemplo, redirigir a la página de login
            });
        } else {
            Swal.fire({
                title: 'Error',
                text: data.message,
                icon: 'error',
                confirmButtonText: 'Aceptar'
            });
        }
    })
    .catch(error => {
        console.error('Error:', error);
        Swal.fire({
            title: 'Error',
            text: 'Hubo un problema con el registro. Inténtalo de nuevo.',
            icon: 'error',
            confirmButtonText: 'Aceptar'
        });
    });
});

document.getElementById('loginForm').addEventListener('submit', function (e) {
    e.preventDefault(); // Evita el envío normal del formulario

    var formData = new FormData(this);

    fetch('procesos/login.php', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        console.log('Server Response Status:', response.status); // Loguea el status de la respuesta
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return response.json();
    })
    .then(data => {
        console.log('Server Response Data:', data); // Loguea los datos recibidos
        if (data.status === 'success') {
            Swal.fire({
                title: 'Éxito',
                text: data.message,
                icon: 'success'
            }).then(() => {
                console.log('Redirigiendo a home.php');
                window.location.href = 'home.php';  // Redirige si el inicio de sesión es exitoso
            });
        } else {
            Swal.fire({
                title: 'Error',
                text: data.message,
                icon: 'error'
            });
        }
    })
    .catch(error => {
        console.error('Fetch Error:', error); // Loguea el error
        Swal.fire({
            title: 'Error',
            text: 'Hubo un problema al procesar la solicitud.',
            icon: 'error'
        });
    });
});

</script>

</body>
</html>