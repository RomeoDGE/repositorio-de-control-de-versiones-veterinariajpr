<?php
session_start();

// Verificar si el usuario está autenticado
if (!isset($_SESSION['autenticado']) || $_SESSION['autenticado'] !== true) {
    header("Location: index.php");
    exit;
}

include '../procesos/conexion.php';

if (isset($_POST['delete_cita_id'])) {
    $id_cita = $_POST['delete_cita_id'];
    $sql_delete = "DELETE FROM agendar_citas WHERE id_cita = ?";

    if ($stmt = $mysqli->prepare($sql_delete)) {
        $stmt->bind_param("i", $id_cita);
        if ($stmt->execute()) {
            // Redirigir con parámetro de éxito
            header("Location: ver_citas.php?status=success");
            exit;
        } else {
            // Redirigir con parámetro de error
            header("Location: ver_citas.php?status=error");
            exit;
        }
        $stmt->close();
    } else {
        // Redirigir con parámetro de error
        header("Location: ver_citas.php?status=error");
        exit;
    }
}

if ($mysqli->connect_error) {
    die("Error de conexión: " . $mysqli->connect_error);
}

?>



<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="styles.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <title>Ver Citas</title>
    <style>
        body {
            background-color: #0cd4da;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .cita-box {
            width: 800px; /* Aumentamos el ancho del recuadro para mostrar la tabla */
            background-color: #FFF; /* Color de fondo blanco */
            padding: 20px;
            border-radius: 15px;
            text-align: center;
        }
        .banner {
            background-color: #019972;
            color: white;
            padding: 10px;
            border-radius: 5px;
            font-size: 24px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .banner img {
            width: 50px; /* Ancho de los logos */
        }
        .table-container {
            margin-top: 20px;
            overflow-x: auto; /* Agregamos un desplazamiento horizontal para la tabla */
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        th, td {
            border: 1px solid #555;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #b00060;
            color: white;
        }
        .back-button {
            position: absolute;
            top: 20px; /* Ajusta la posición superior según tu diseño */
            left: 20px; /* Ajusta la posición izquierda según tu diseño */
            cursor: pointer;
            padding: 10px; /* Agrega un relleno al botón para darle más espacio */
        }
        .delete-button {
            background-color: #d33; /* Rojo para indicar eliminación */
            color: white;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <a href="javascript:history.back()" class="back-button">
        <svg width="45" height="45" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
            <path d="M512 256A256 256 0 1 0 0 256a256 256 0 1 0 512 0zM217.4 376.9L117.5 269.8c-3.5-3.8-5.5-8.7-5.5-13.8s2-10.1 5.5-13.8l99.9-107.1c4.2-4.5 10.1-7.1 16.3-7.1c12.3 0 22.3 10 22.3 22.3l0 57.7 96 0c17.7 0 32 14.3 32 32l0 32c0 17.7-14.3 32-32 32l-96 0 0 57.7c0 12.3-10 22.3-22.3 22.3c-6.2 0-12.1-2.6-16.3-7.1z"/>
        </svg>
    </a>
    <div class="container">
        <div class="cita-box">
            <div class="banner">
                <img src="../imgvet/citas.svg" alt="Logo Izquierdo">
                Citas Agendadas
                <img src="../imgvet/citas.svg" alt="Logo Derecho">
            </div>
            <div class="search-form">
                <form method="GET" action=""><br>
                    <input type="text" name="search" placeholder="Buscar por codigo">
                    <button type="submit" class="btn btn-light btn-lg btn-custom">Buscar</button>
                </form>
            </div>
            <div class="table-container">
                <?php
                include '../procesos/conexion.php';

                $sql = "SELECT c.id_cita, c.fecha_cita, c.hora_cita, m.codigo_mascota
                        FROM agendar_citas c
                        INNER JOIN mascotas m ON c.codigo_mascota = m.codigo_mascota";

                if (isset($_GET['search'])) {
                    $searchTerm = $_GET['search'];
                    $sql .= " WHERE m.codigo_mascota LIKE '%$searchTerm%'";
                }

                if ($result = $mysqli->query($sql)) {
                    if ($result->num_rows > 0) {
                        echo '<table>';
                        echo '<tr><th>ID Cita</th><th>Fecha</th><th>Hora</th><th>Codigo Mascota</th><th>Acciones</th></tr>';
                        while ($row = $result->fetch_assoc()) {
                            echo '<tr>';
                            echo '<td>' . htmlspecialchars($row['id_cita']) . '</td>';
                            echo '<td>' . htmlspecialchars($row['fecha_cita']) . '</td>';
                            echo '<td>' . htmlspecialchars($row['hora_cita']) . '</td>';
                            echo '<td>' . htmlspecialchars($row['codigo_mascota']) . '</td>';
                            echo '<td>';
                            echo '<form method="POST" action="" class="delete-form">';
                            echo '<input type="hidden" name="delete_cita_id" value="' . htmlspecialchars($row['id_cita']) . '">';
                            echo '<button type="button" class="delete-button" onclick="confirmDelete(this)">Eliminar</button>';
                            echo '</form>';
                            echo '</td>';
                            echo '</tr>';
                        }
                        echo '</table>';
                    } else {
                        echo '<p>No hay citas disponibles.</p>';
                    }
                } else {
                    echo '<p>Error al ejecutar la consulta SQL: ' . $mysqli->error . '</p>';
                }

                $mysqli->close();
                ?>
            </div>
        </div>
    </div>

    <script>
        function confirmDelete(button) {
            Swal.fire({
                title: "¿Estás seguro?",
                text: "Esta acción eliminará la cita de manera permanente.",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#3085d6",
                cancelButtonColor: "#d33",
                confirmButtonText: "Sí, eliminar",
                cancelButtonText: "Cancelar"
            }).then((result) => {
                if (result.isConfirmed) {
                    // Si el usuario confirma, enviar el formulario
                    button.closest("form").submit();
                }
            });
        }

        // Mostrar la alerta basado en el parámetro de la URL
        const urlParams = new URLSearchParams(window.location.search);
        const status = urlParams.get('status');

        if (status === 'success') {
            Swal.fire({
                icon: "success",
                title: "Cita Eliminada",
                text: "La cita se ha eliminado exitosamente",
                showConfirmButton: true
            }).then(() => {
                // Eliminar el parámetro de la URL después de mostrar la alerta
                window.history.replaceState(null, null, window.location.pathname);
            });
        } else if (status === 'error') {
            Swal.fire({
                icon: "error",
                title: "Error",
                text: "No se pudo eliminar la cita",
                showConfirmButton: true
            }).then(() => {
                window.history.replaceState(null, null, window.location.pathname);
            });
        }
    </script>
</body>
</html>